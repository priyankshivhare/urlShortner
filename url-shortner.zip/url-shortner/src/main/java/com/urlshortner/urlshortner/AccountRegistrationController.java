package com.urlshortner.urlshortner;

import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

//import java.util.HashMap;
//import java.util.LinkedHashMap;


@RestController
public class AccountRegistrationController {
    //HashMap<Integer, AccountRegistration> accounts = new LinkedHashMap<>();
    private int[] accountIds = new int[50];
    private String[] accountPasswords = new String[50];
    private String[] urls = new String[50];
    private String[] shortUrls = new String[50];
    private int counter = 0;
    private int urlCounter = 0;

    private int matchString(final String[] array, final String v) {

        int result = -1;

        for(int i=0; i<array.length; i++){
            if(array[i].equals(v)){
                result = i;
                break;
            }
        }

        return result;
    }

    @PostMapping(path = "/account")
    public String accountInformation(@RequestBody AccountRegistration account) {
        if(account.contains(accountIds, account.getAccountId())) {
            return "Account already exists";
        } else {
            String accountPw = account.getAccountPassword();
            accountIds[counter] = account.getAccountId();
            accountPasswords[counter] = accountPw;
            counter++;
            return "Your account is opened, your password is: " + accountPw;
        }
    }

    @PostMapping(path = "/register")
    public String urlInformation(@RequestHeader("Authorization") String authorization, @RequestBody UrlRegistration urlData) {
        int accountIndex = urlData.contains(accountIds, urlData.getaccountId());
        if(accountIndex > -1) {
            if(authorization.equals(accountPasswords[accountIndex])) {
                String generatedShortUrl = urlData.getShortUrl();
                urls[urlCounter] = urlData.getUrl();
                shortUrls[urlCounter] = generatedShortUrl;
                urlCounter++;
                return "Account verified, your url is " + generatedShortUrl;
            } else {
                return "Authorization failed";
            }
        } else {
            return "Account doesn't exist";
        }
    }

    @GetMapping("/{shortUrl}")
    @ResponseBody
    public void urlRedirect(HttpServletResponse httpServletResponse, @PathVariable String shortUrl) {
        int urlIndex = matchString(shortUrls, shortUrl);
        if (urlIndex > -1) {
            httpServletResponse.setHeader("Location", urls[urlIndex]);
            httpServletResponse.setStatus(302);
        } else {
            httpServletResponse.setHeader("Location", "http://www.example.com");
            httpServletResponse.setStatus(404);
        }

    }
}
