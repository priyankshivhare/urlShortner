package com.urlshortner.urlshortner;

import java.util.Random;

public class UrlRegistration {
    private int accountId;
    private String url;

    public UrlRegistration(int accountId, String url) {
        this.accountId = accountId;
        this.url = url;
    }

    public String getShortUrl() {
        String URLCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefijklpqrsvwxyz";
        StringBuilder urlString = new StringBuilder();
        Random rnd = new Random();
        while (urlString.length() < 4) { // length of the random string.
            int index = (int) (rnd.nextFloat() * URLCHARS.length());
            urlString.append(URLCHARS.charAt(index));
        }
        String urlStr = urlString.toString();
        return urlStr;

    }

    public String getUrl() {
        return url;
    }

    public int getaccountId() {
        return accountId;
    }

    public int contains(final int[] array, final int v) {

        int result = -1;

        for(int i=0; i<array.length; i++){
            if(array[i] == v){
                result = i;
                break;
            }
        }

        return result;
    }
}
