package com.urlshortner.urlshortner;

import java.util.Random;

public class AccountRegistration {
    private int accountId;


    public AccountRegistration(int accountId, boolean accountStatus, String accountPassword) {
        this.accountId = accountId;
    }

    private String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 9) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }

    public int getAccountId() {
        return accountId;
    }


    public String getAccountPassword() {
        return getSaltString();
    }


    public boolean contains(final int[] array, final int v) {

        boolean result = false;

        for(int i : array){
            if(i == v){
                result = true;
                break;
            }
        }

        return result;
    }
}
